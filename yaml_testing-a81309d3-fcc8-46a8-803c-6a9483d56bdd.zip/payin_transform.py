def transform(df):
    # You can modify or enrich the data here
    df['age'] = df['age'].fillna(0)
    return df
