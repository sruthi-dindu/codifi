import boto3
import yaml
import pandas as pd
import io
import logging

# Setup logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client('s3')

def load_yaml_config():
    with open('config.yaml', 'r') as f:
        return yaml.safe_load(f)

def lambda_handler(event, context):
    try:
        # 1. Load config from local YAML
        config = load_yaml_config()
        logger.info("Loaded config: %s", config)

        # 2. Read file from S3 with column pruning
        all_possible_source_cols = set(col for cols in config['column_mapping'].values() for col in cols)

        obj = s3.get_object(Bucket=config['source_bucket'], Key=config['source_key'])
        file_stream = obj['Body']
        
        df = pd.read_csv(file_stream, delimiter='|', usecols=lambda col: col in all_possible_source_cols)
        logger.info("Loaded DataFrame with columns: %s", df.columns.tolist())

        # 3. Apply column mapping with fallback to null
        for target_col, possible_sources in config['column_mapping'].items():
            matched = False
            for source_col in possible_sources:
                if source_col in df.columns:
                    df[target_col] = df[source_col]
                    matched = True
                    break
            if not matched:
                df[target_col] = pd.NA
                logger.warning("None of %s found. Filled '%s' with nulls.", possible_sources, target_col)

        # 4. Drop all unmapped/intermediate columns to save memory
        df = df[list(config['column_mapping'].keys())]

        # 5. Ensure all partition keys exist
        for key in config['partition_keys']:
            if key not in df.columns:
                raise KeyError(f"Missing partition key column: {key}")

        # 6. Partition and write to S3 with error handling
        partition_keys = config['partition_keys']
        dest_bucket = config['destination_bucket']
        dest_prefix = config['destination_prefix']

        grouped = df.groupby(partition_keys)
        partition_count = 0

        for partition_vals, group in grouped:
            try:
                if isinstance(partition_vals, str):
                    partition_vals = [partition_vals]

                partition_path = '/'.join([f"{k}={v}" for k, v in zip(partition_keys, partition_vals)])
                filename = "_".join(str(v) for v in partition_vals) + ".csv"
                output_key = f"{dest_prefix}{partition_path}/{filename}"

                csv_buffer = io.StringIO()
                group.to_csv(csv_buffer, index=False)

                s3.put_object(Bucket=dest_bucket, Key=output_key, Body=csv_buffer.getvalue())
                partition_count += 1

                logger.info("Uploaded partition: %s", output_key)

            except Exception as partition_error:
                logger.error("Error processing partition %s: %s", partition_vals, str(partition_error))

        return {
            'status': 'success',
            'partitions_created': partition_count,
            'partition_keys': partition_keys
        }

    except Exception as e:
        logger.error("Fatal error in Lambda: %s", str(e))
        raise e  # Allow DLQ to handle unrecoverable errors
