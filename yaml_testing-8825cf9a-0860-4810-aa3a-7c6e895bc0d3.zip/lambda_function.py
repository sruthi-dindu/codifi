import boto3
import yaml
import pandas as pd
import io
import logging
from datetime import datetime

# Setup logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client('s3')

def load_yaml_config():
    with open('config.yaml', 'r') as f:
        return yaml.safe_load(f)

def get_latest_s3_file(bucket, prefix):
    response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)
    if 'Contents' not in response or len(response['Contents']) == 0:
        raise FileNotFoundError(f"No files found with prefix '{prefix}' in bucket '{bucket}'")

    latest_obj = max(response['Contents'], key=lambda x: x['LastModified'])
    return latest_obj['Key']

def find_valid_column(df, candidates):
    for col in candidates:
        if col in df.columns:
            return col
    return None

def try_multiple_date_formats(series, formats):
    for fmt in formats:
        try:
            converted = pd.to_datetime(series, format=fmt, errors='coerce')
            if not converted.isna().all():
                return converted
        except Exception:
            continue
    return pd.to_datetime(series, errors='coerce')  # fallback

def lambda_handler(event, context):
    try:
        # Load config
        config = load_yaml_config()
        logger.info("Loaded config: %s", config)

        # Determine source key
        if config.get('auto_pick_latest_file', False):
            source_key = get_latest_s3_file(config['source_bucket'], config['file_prefix'])
            logger.info("Auto-picked latest file: %s", source_key)
        else:
            source_key = config['source_key']

        # Read file from S3
        obj = s3.get_object(Bucket=config['source_bucket'], Key=source_key)
        file_stream = obj['Body']

        # Prune columns to read
        all_possible_source_cols = set(col for cols in config['column_mapping'].values() for col in cols)
        date_validation_cols = config.get('date_validation', {}).get('columns', [])
        all_possible_source_cols.update(date_validation_cols)

        df = pd.read_csv(file_stream, delimiter=config.get('delimiter', '|'),
                         usecols=lambda col: col in all_possible_source_cols)

        logger.info("Loaded DataFrame with columns: %s", df.columns.tolist())

        # Date validation
        date_validation = config.get('date_validation', {})
        if date_validation.get('enabled', False):
            date_col = find_valid_column(df, date_validation['columns'])
            if not date_col:
                raise ValueError(f"None of the date columns {date_validation['columns']} found in file")

            formats = date_validation.get("expected_format")
            if isinstance(formats, str):
                formats = [formats]

            df[date_col] = try_multiple_date_formats(df[date_col], formats)
            max_date_in_file = df[date_col].max().date()

            max_timestamp = datetime.strptime(date_validation.get("max_timestamp"), "%Y-%m-%d").date()

            if max_date_in_file != max_timestamp:
                raise ValueError(f"Skipping file {source_key} — max date {max_date_in_file} ≠ expected {max_timestamp}")
            logger.info("Date validation passed: max date matches expected date")

        # Apply column mapping with fallback
        for target_col, possible_sources in config['column_mapping'].items():
            matched = False
            for source_col in possible_sources:
                if source_col in df.columns:
                    df[target_col] = df[source_col]
                    matched = True
                    break
            if not matched:
                df[target_col] = pd.NA
                logger.warning("Column mapping: filled '%s' with nulls (sources tried: %s)", target_col, possible_sources)

        # Drop intermediate columns
        df = df[list(config['column_mapping'].keys())]

        # Validate partition keys
        for key in config['partition_keys']:
            if key not in df.columns:
                raise KeyError(f"Missing partition key column: {key}")

        # Partition and upload
        partition_keys = config['partition_keys']
        dest_bucket = config['destination_bucket']
        dest_prefix = config['destination_prefix']

        grouped = df.groupby(partition_keys)
        partition_count = 0

        for partition_vals, group in grouped:
            try:
                if isinstance(partition_vals, str):
                    partition_vals = [partition_vals]

                partition_path = '/'.join([f"{k}={v}" for k, v in zip(partition_keys, partition_vals)])
                filename = "_".join(str(v) for v in partition_vals) + ".csv"
                output_key = f"{dest_prefix}{partition_path}/{filename}"

                csv_buffer = io.StringIO()
                group.to_csv(csv_buffer, index=False)

                s3.put_object(Bucket=dest_bucket, Key=output_key, Body=csv_buffer.getvalue())
                partition_count += 1

                logger.info("Uploaded: %s", output_key)

            except Exception as part_err:
                logger.error("Error in partition %s: %s", partition_vals, str(part_err))

        return {
            'status': 'success',
            'source_key': source_key,
            'partitions_created': partition_count
        }

    except Exception as e:
        logger.error("Fatal error: %s", str(e))
        raise e